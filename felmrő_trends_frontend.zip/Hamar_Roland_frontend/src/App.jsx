import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import { Home } from './Components/Home'
import { Trends } from './Components/Trends'


const router = createBrowserRouter([
  {path:"/",element:<Home/>},
  {path:"/trends/:id",element:<Trends/>}
])
function App() {
 

  return <RouterProvider router={router}/>
    
  
}

export default App
