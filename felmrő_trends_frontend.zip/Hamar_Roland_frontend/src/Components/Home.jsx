import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { getData } from '../utils'
import { useNavigate } from 'react-router-dom'
const url = "http://localhost:8000/api/categories"

export const Home = () => {
    const { data, isLoading, isError, error } = useQuery({ queryKey: ['categories', url], queryFn: getData })
    const navigate = useNavigate()
    if (isLoading) return <div>Loading...</div>
    if (isError) return <div>Error: {error.message}</div>
        data &&console.log(data);   
  return (
    <div className="container">
    
                
    <div className="listings-container">
    {data && data.map(obj =>
        <div className="listing-card">
            <div className="card-header">
                <span className="title">{obj.name}</span>
                
            </div>
            <div className="card-body">
                <p></p>
            </div>
           
            <div className="card-footer">
                <a onClick={()=>navigate('/trends/'+obj.id)}><button className="btn " popovertarget="contactFormPopup">Olvass</button></a>
            </div>
  
        </div>
           )}
           </div>
</div>
    
  )
}


