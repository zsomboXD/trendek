
import React from 'react'
import { getData } from '../utils'
import { useNavigate, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'

export const Trends = () => {
    const url = "http://localhost:8000/api/trends/"
    const {id} = useParams()
    const {data,isLoading,isError,error} = useQuery({queryKey:['trends',url+id],queryFn:getData})
    const navigate = useNavigate()
    data &&console.log(data[0].name);
    console.log(data);
  return (
    <>
    <div onClick={()=>navigate("/")} className='back'></div>
    {data && data.map(obj=>
        <div className='container'>
        <h2>{data[0].name}</h2>
        <p>{data[0].description}</p>
      </div>
    )
    
    
    
    }
    </>
  )
}


