import React from 'react'

const SearchResult = () => {
  return (
    <div>
      <input type="text" />
    </div>
  )
}

export default SearchResult
