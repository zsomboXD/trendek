import './App.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { Home } from './components/Home'
import { Trends } from './components/Trends'


const router = createBrowserRouter([
  {path:"/",element:<Home/>},
  {path:"/trends/:id",element:<Trends/>},

])


function App() {
  return <RouterProvider router={router}/>
}

export default App
