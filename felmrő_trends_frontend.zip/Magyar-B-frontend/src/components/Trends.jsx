import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'

import { useParams } from 'react-router-dom'
import { getData } from '../../utils'

const url = 'http://localhost:3000/api/trends/'

export const Trends = () => {
    const [trends, setTrends]=useState([])
    const {id}=useParams()    

      
    useEffect(()=>{
        getData(url+id,setTrends)
    },[])

  return (
    <div className='t w-full bg-gray-700'>
         <div className='trends bg-gray-700 grid grid-cols-4 w-full h-full'>
       {trends && trends.map((obj)=>
       <div key={obj.name} className="max-w-sm bg-amber-50 gap-2 rounded overflow-hidden shadow-lg">
       <img className="w-full" src={obj.imageUrl} alt="Sunset in the mountains"></img>
       <div className="px-6 py-4">
         <div className="font-bold text-xl mb-2">{obj.name}</div>
         <p className="text-gray-700 text-base">
           {obj.description}
         </p>
       </div>
       <div className="px-6 pt-4 pb-2">
         <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2">{obj.impact}</span>

       </div>
     </div>
        )}
    </div>
    </div>
   
  )
}


