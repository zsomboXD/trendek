import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getData } from '../../utils'
import { useEffect } from 'react'

const url = 'http://localhost:3000/api/categories'

export const Home = () => {
    const [categ, setCateg]=useState([])
    const navigate = useNavigate()

     useEffect(()=>{
        getData(url,setCateg)
     },[])


  return (
    <div className='d'>

<main className='container bg-gray-700 w-full justify-center'>
        <div className='banner flex flex-wrap justify-center h-40'>
           <h1 className='underline text-7xl text-red-50'>Tech trendek</h1>
        </div>

        <div className='search'>
            <input type="text" />
            <input type="button" value="" />
        </div>
       <div className='row flex flex-wrap gap-5'>
        {categ && categ.map((obj)=>
       <div key={obj.id} className="max-w-sm rounded w-70 h-50 bg-white overflow-hidden shadow-lg">
        <div className="px-6 py-4">
            <div  className="font-bold text-xl mb-2">{obj.name}</div>
            <p className="text-gray-700 text-base">
            <a onClick={()=>navigate('/trends/'+obj.id)} className='text-blue-600 hover:text-blue-400'>Olvass</a>
            </p>
        </div>

        </div>)}
       </div>
        

    </main>

    </div>
    
  )
}

 
