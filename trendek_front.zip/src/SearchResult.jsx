import React from 'react'

export const SearchResult = () => {
  return (
    <div>SearchResult</div>
  )
}
