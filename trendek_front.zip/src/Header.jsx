import React from 'react'
import { useNavigate } from 'react-router-dom'

export const Header = () => {
    const navigate = useNavigate()
  return (
    <Header>
        <button onClick={()=> navigate('/')}>◀◀
        </button>
    </Header>
  )
}
