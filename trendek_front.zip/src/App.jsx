import 'bootstrap/dist/css/bootstrap.min.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import { Home } from './Home'
import { Trends } from './Trends'
import { SearchResult } from './SearchResult'

const router=createBrowserRouter([
  {path:'/',element:<Home />},
  {path:'/trends',element:<Trends />},
  {path:'/searchresult',element:<SearchResult />},
])

function App() {
  return <RouterProvider router={router}/>
}

export default App
