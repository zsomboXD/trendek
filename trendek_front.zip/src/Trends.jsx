import React from 'react'

export const Trends = () => {
  return (
    <div>Trends</div>
  )
}
