import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Header } from './Header'
import { Card, CardBody, CardTitle, Col } from 'reactstrap'
import { getData } from './utils'
import { useQuery } from '@tanstack/react-query'

const url="http://localhost:8000/api/categories"

export const Home = () => {
  const navigate = useNavigate()
  const {data}=useQuery({queryKey:['categories',url],queryFn:getData})

  data && console.log(data);

  return (
    <div>
      <h1>Tech Trendek</h1>
      {data && data.map(obj=>

          <div className="container">
          <div className="row">
              <div className="col-lg-4">
                  <div className="card card-margin">
                      <div className="card-header no-border">
                          <h2 className="card-title">{obj.name}</h2>
                      </div>
                      <div className="card-body pt-0">
                          <div className="widget-49">
                              <div className="widget-49-title-wrapper">
                              </div>
                              <div className="widget-49-meeting-action">
                                  <a href="#" className="btn btn-sm btn-flash-border-primary"> Olvass--{">"}</a>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          </div>
  )}





    </div>
  )
}
