import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Home from "./components/HomeLayout"
import Trends from "./pages/Trends";
import NotFound from "./pages/NotFound";

function App() {
 
  const router = createBrowserRouter(
    [
      { path: "/", element: <Home /> },
      { path: "/trends/:id", element: <Trends /> },
      { path: "*", element: <NotFound /> }
    ],
    {
      future: {
        v7_relativeSplatPath: true,
  
        v7_normalizeFormMethod: true,
  
        v7_fetcherPersist: true,
  
        v7_partialHydration: true,
  
        v7_skipActionErrorRevalidation: true,
      },
    },
  );

  return (
    <RouterProvider router={router} future={{ v7_startTransition: true }} />
  )
}

export default App
