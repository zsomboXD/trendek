import React from 'react'
import HomeLayout from '../components/HomeLayout'

const Home = () => {
  return (
    <>
        <HomeLayout />
    </>
  )
}

export default Home
