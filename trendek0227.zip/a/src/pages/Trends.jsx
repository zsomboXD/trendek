import React from 'react'
import TrendsLayout from '../components/TrendsLayout'

const Trends = ({id}) => {
  return (
  <>
    <TrendsLayout />
  </>
  )
}

export default Trends
