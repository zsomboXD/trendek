import React from 'react'
import { Link } from 'react-router-dom'

const NotFound = () => {
  return (
    <section className='flex min-h-screen justify-center items-center bg-sky-950 flex-col gap-4'>
      <h1 className='text-serif text-5xl  text-indigo-500'>- 404 -</h1>
      <Link to={"/"} className='text-4xl italic font-serif text-indigo-500 underline'>Vissza a Főoldalra</Link>
    </section>
  )
}

export default NotFound
