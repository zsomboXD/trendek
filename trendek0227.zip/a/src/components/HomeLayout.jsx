import { useQuery } from '@tanstack/react-query'
import { MoveRight } from 'lucide-react'
import { Bookmark } from 'lucide-react'
import React from 'react'
import { Link } from 'react-router-dom'
import SearchBox from './SearchBox'

const HomeLayout = () => {

    const { data } = useQuery({ queryKey: ['trendek'], queryFn: () => fetch("http://localhost:3000/api/categories").then(res => res.json()) })

    return (
        <section className='bg-sky-950 min-h-screen flex justify-start items-center px-2 md:px-24 py-4 flex-col gap-6'>
            <div className="flex justify-center items-center max-h-[500px] relative w-full">
                <img src='/banner.jpg' alt='Banner' className='object-cover max-h-[500px] w-full rounded-xl' />
                <h1 className='absolute mb-10 md:mb-0 left-0 w-full mx-auto text-center z-10 text-3xl md:text-8xl text-white font-serif underline'>Tech trendek</h1>
                <SearchBox className="absolute md:right-8 md:w-fit bottom-4"/>
            </div>
            {data &&
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 justify-center items-center w-full gap-x-16 gap-y-12 px-6 md:px-24">
                    {data.map((e, i) => (
                        <div key={e.id} className="flex relative col-span-1 hover:scale-105 transition-all justify-center items-center bg-white rounded-xl h-52 font-serif">
                            <Bookmark className='absolute top-8 left-8 size-8 text-indigo-600' />
                            <div className="flex justify-center items-center flex-col text-left w-fit">
                                <h2 className='text-lg w-full'>{e.name}</h2>
                                <Link to={"/trends/"+e.id} className='w-full flex flex-row gap-2 text-lg justify-start items-center text-indigo-600'>
                                    Olvass
                                    <MoveRight className='size-4'/>
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            }
        </section>
    )
}

export default HomeLayout
