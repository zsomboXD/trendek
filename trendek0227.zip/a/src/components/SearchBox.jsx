import { Search } from 'lucide-react'
import React from 'react'
import { twMerge } from 'tailwind-merge'

const SearchBox = ({ className }) => {
  return (
    <div className={twMerge('flex justify-center items-center w-full h-fit flex-row gap-2 md:px-0 px-8', className)}>
      <div className='flex justify-center items-center h-fit bg-neutral-600 w-full md:w-fit rounded-xl p-2 flex-row gap-2'>
        <div className="flex justify-start md:justify-center items-center md:w-fit w-full h-fit gap-3">
          <Search className='text-neutral-400' />
          <input type="text" placeholder='Search...' className='text-neutral-400 placeholder:text-neutral-400 w-32' />
        </div>
        <button className='rounded-xl bg-indigo-500 px-4 py-2 text-white'>Search</button>
      </div>
    </div>
  )
}

export default SearchBox
