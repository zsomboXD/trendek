import 'bootstrap/dist/css/bootstrap.min.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import { Home } from './components/Home';
import { Trends } from './components/Trends';
import { SearchResult } from './components/SearchResult';


const router=createBrowserRouter([
  {path:'/',element:<Home />},
  {path: "/trends/:id", element: <Trends /> },
  {path:'/searchresult',element:<SearchResult />},
])

function App() {
  return <RouterProvider router={router}/>
}

export default App
