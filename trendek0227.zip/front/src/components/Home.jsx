import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getData } from '../utils'

const url = "http://localhost:8000/api/categories"

export const Home = () => {
    const navigate = useNavigate()
    const { data } = useQuery({ queryKey: ['categories', url], queryFn: getData })

    data && console.log(data);

    return (
        <div>
            <div>
                <img style={{width:"500px"}} src='/banner.jpg' alt='Banner' />
                <h1>Tech Trendek</h1>
            </div>

            {data && data.map(obj =>
                <div className="container">
                    <div className="row">
                        <div className="col-lg-4">
                            <div className="card card-margin">
                                <div className="card-header no-border">
                                    <h2 className="card-title">{obj.name}</h2>
                                </div>
                                <div className="card-body pt-0">
                                    <div className="widget-49">
                                        <div className="widget-49-title-wrapper">
                                        </div>
                                        <div className="widget-49-meeting-action">
                                            <Link to={"/trends/" + obj.id}> Olvass--{">"}</Link>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    )
}